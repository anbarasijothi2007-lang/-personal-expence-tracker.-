// ========================================
// PERSONAL EXPENSE TRACKING APPLICATION
// ========================================

const STORAGE_KEY = "personal_expense_tracking_data";
const CATEGORY_KEY = "personal_expense_tracking_categories";

const DEFAULT_CATEGORIES = [
    "Food & Dining",
    "Transport",
    "Shopping",
    "Bills & Utilities",
    "Health",
    "Entertainment",
    "Education",
    "Salary",
    "Freelance",
    "Other"
];

let transactions = loadData(STORAGE_KEY, []);
let categories = loadData(CATEGORY_KEY, DEFAULT_CATEGORIES);
let expenseChart = null;
let showAllTransactions = false;
let toastTimer;


// ========================================
// HELPER FUNCTIONS
// ========================================

function loadData(key, fallback) {
    try {
        const saved = localStorage.getItem(key);

        if (saved === null) {
            return fallback;
        }

        const parsed = JSON.parse(saved);

        return Array.isArray(parsed) ? parsed : fallback;

    } catch (error) {
        console.error("Unable to load saved data:", error);
        return fallback;
    }
}


function saveData() {
    try {
        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(transactions)
        );

        localStorage.setItem(
            CATEGORY_KEY,
            JSON.stringify(categories)
        );

        return true;

    } catch (error) {
        console.error("Unable to save data:", error);

        showToast(
            "Storage failed. Check your browser storage settings."
        );

        return false;
    }
}


function money(amount) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(Number(amount) || 0);
}


function todayString() {
    const date = new Date();

    date.setMinutes(
        date.getMinutes() - date.getTimezoneOffset()
    );

    return date.toISOString().slice(0, 10);
}


function formatDate(value) {
    if (!value) return "—";

    const parts = value.split("-");

    if (parts.length !== 3) return value;

    return new Date(
        Number(parts[0]),
        Number(parts[1]) - 1,
        Number(parts[2])
    ).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}


function monthKey(date) {
    return date.slice(0, 7);
}


function currentMonthKey() {
    return monthKey(todayString());
}


function monthName(key) {
    const parts = key.split("-");

    return new Date(
        Number(parts[0]),
        Number(parts[1]) - 1,
        1
    ).toLocaleDateString("en-IN", {
        month: "long",
        year: "numeric"
    });
}


function totalAmount(list, type) {
    return list
        .filter(item => item.type === type)
        .reduce(
            (sum, item) => sum + Number(item.amount),
            0
        );
}


function escapeHTML(value) {
    return String(value ?? "").replace(
        /[&<>"']/g,
        character => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        })[character]
    );
}


function showToast(message) {
    const toast = document.getElementById("toast");

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 2600);
}


// ========================================
// CATEGORY MANAGEMENT
// ========================================

function renderCategories() {
    const categorySelect =
        document.getElementById("category");

    const filterSelect =
        document.getElementById("filterCategory");

    const previousFilter = filterSelect.value;
    const previousCategory = categorySelect.value;

    filterSelect.innerHTML =
        '<option value="all">All Categories</option>';

    categorySelect.innerHTML = "";

    categories.forEach(category => {
        const option1 = document.createElement("option");

        option1.value = category;
        option1.textContent = category;

        categorySelect.appendChild(option1);

        const option2 = document.createElement("option");

        option2.value = category;
        option2.textContent = category;

        filterSelect.appendChild(option2);
    });

    if (categories.includes(previousCategory)) {
        categorySelect.value = previousCategory;
    }

    if (categories.includes(previousFilter)) {
        filterSelect.value = previousFilter;
    } else {
        filterSelect.value = "all";
    }

    renderCategoryList();
}


function renderCategoryList() {
    const container =
        document.getElementById("categoryList");

    container.innerHTML = "";

    categories.forEach(category => {
        const chip = document.createElement("div");

        chip.className = "category-chip";

        const name = document.createElement("span");

        name.textContent = category;

        chip.appendChild(name);

        // Default categories cannot be removed.
        if (!DEFAULT_CATEGORIES.includes(category)) {
            const removeButton =
                document.createElement("button");

            removeButton.type = "button";
            removeButton.textContent = "×";
            removeButton.title = "Remove category";

            removeButton.addEventListener("click", () => {
                removeCategory(category);
            });

            chip.appendChild(removeButton);
        }

        container.appendChild(chip);
    });
}


function addCategory(event) {
    event.preventDefault();

    const input =
        document.getElementById("newCategory");

    const name = input.value.trim();

    if (!name) {
        showToast("Enter a category name.");
        return;
    }

    const alreadyExists = categories.some(
        category =>
            category.toLowerCase() === name.toLowerCase()
    );

    if (alreadyExists) {
        showToast("This category already exists.");
        return;
    }

    categories.push(name);

    if (!saveData()) {
        categories.pop();
        return;
    }

    input.value = "";

    renderCategories();

    showToast("Category added successfully!");
}


function removeCategory(category) {
    const isUsed = transactions.some(
        transaction => transaction.category === category
    );

    if (isUsed) {
        showToast(
            "This category is in use. Change its transactions first."
        );

        return;
    }

    const confirmed = confirm(
        `Remove the category "${category}"?`
    );

    if (!confirmed) return;

    const oldCategories = [...categories];

    categories = categories.filter(
        item => item !== category
    );

    if (!saveData()) {
        categories = oldCategories;
        return;
    }

    renderCategories();

    showToast("Category removed.");
}


// ========================================
// SUMMARY CALCULATIONS
// ========================================

function renderSummary() {
    const income = totalAmount(
        transactions,
        "income"
    );

    const expenses = totalAmount(
        transactions,
        "expense"
    );

    const balance = income - expenses;

    document.getElementById("balance").textContent =
        money(balance);

    document.getElementById("totalIncome").textContent =
        money(income);

    document.getElementById("totalExpense").textContent =
        money(expenses);


    // Current month calculations.

    const key = currentMonthKey();

    const monthlyTransactions = transactions.filter(
        transaction => monthKey(transaction.date) === key
    );

    const monthlyIncome = totalAmount(
        monthlyTransactions,
        "income"
    );

    const monthlyExpenses = totalAmount(
        monthlyTransactions,
        "expense"
    );

    const monthlyNet = monthlyIncome - monthlyExpenses;

    document.getElementById("monthlyBalance").textContent =
        money(monthlyNet);

    document.getElementById("currentMonth").textContent =
        monthName(key);

    document.getElementById("monthIncome").textContent =
        money(monthlyIncome);

    document.getElementById("monthExpense").textContent =
        money(monthlyExpenses);

    document.getElementById("netSavings").textContent =
        money(monthlyNet);


    // Percentage of monthly income spent.

    const percentage = monthlyIncome > 0
        ? Math.round(
            monthlyExpenses / monthlyIncome * 100
        )
        : monthlyExpenses > 0 ? 100 : 0;

    document.getElementById("spentPercentage").textContent =
        percentage + "%";

    document.getElementById("spentProgress").style.width =
        Math.min(percentage, 100) + "%";
}


// ========================================
// SEARCH AND FILTER
// ========================================

function getFilteredTransactions() {
    const query = document
        .getElementById("searchInput")
        .value.trim()
        .toLowerCase();

    const type = document
        .getElementById("filterType")
        .value;

    const category = document
        .getElementById("filterCategory")
        .value;

    const startDate = document
        .getElementById("startDate")
        .value;

    const endDate = document
        .getElementById("endDate")
        .value;


    return [...transactions]
        .filter(transaction => {
            const description =
                transaction.description.toLowerCase();

            const notes =
                (transaction.notes || "").toLowerCase();

            const matchesSearch =
                !query ||
                description.includes(query) ||
                notes.includes(query);

            const matchesType =
                type === "all" ||
                transaction.type === type;

            const matchesCategory =
                category === "all" ||
                transaction.category === category;

            const matchesStart =
                !startDate ||
                transaction.date >= startDate;

            const matchesEnd =
                !endDate ||
                transaction.date <= endDate;

            return (
                matchesSearch &&
                matchesType &&
                matchesCategory &&
                matchesStart &&
                matchesEnd
            );
        })
        .sort((a, b) => {
            return (
                b.date.localeCompare(a.date) ||
                Number(b.createdAt) - Number(a.createdAt)
            );
        });
}


// ========================================
// DISPLAY TRANSACTIONS
// ========================================

function renderTransactions() {
    const tbody =
        document.getElementById("transactionList");

    const emptyState =
        document.getElementById("emptyState");

    const table =
        document.querySelector(".table-wrapper");

    const filtered = getFilteredTransactions();

    const visible = showAllTransactions
        ? filtered
        : filtered.slice(0, 7);

    tbody.innerHTML = "";

    visible.forEach(transaction => {
        const row = document.createElement("tr");

        const descriptionCell =
            document.createElement("td");

        const descriptionStrong =
            document.createElement("strong");

        descriptionStrong.textContent =
            transaction.description;

        const note = document.createElement("small");

        note.textContent =
            transaction.notes ||
            (transaction.type === "income"
                ? "Income recorded"
                : "Expense recorded");

        note.style.display = "block";
        note.style.marginTop = "4px";
        note.style.color = "#9aa6b4";
        note.style.maxWidth = "190px";
        note.style.overflow = "hidden";
        note.style.textOverflow = "ellipsis";

        descriptionCell.appendChild(descriptionStrong);
        descriptionCell.appendChild(note);


        const categoryCell =
            document.createElement("td");

        const categoryTag =
            document.createElement("span");

        categoryTag.className = "tag";
        categoryTag.textContent = transaction.category;

        categoryCell.appendChild(categoryTag);


        const dateCell =
            document.createElement("td");

        dateCell.textContent =
            formatDate(transaction.date);


        const typeCell =
            document.createElement("td");

        const typeTag =
            document.createElement("span");

        typeTag.className =
            "type-tag " + transaction.type;

        typeTag.textContent =
            transaction.type === "income"
                ? "Income"
                : "Expense";

        typeCell.appendChild(typeTag);


        const amountCell =
            document.createElement("td");

        amountCell.className =
            transaction.type === "income"
                ? "amount-income"
                : "amount-expense";

        amountCell.textContent =
            (transaction.type === "income" ? "+" : "−") +
            money(transaction.amount);


        const actionCell =
            document.createElement("td");

        const editButton =
            document.createElement("button");

        editButton.className = "action-btn";
        editButton.textContent = "Edit";

        editButton.addEventListener("click", () => {
            openTransactionModal(transaction.id);
        });


        const deleteButton =
            document.createElement("button");

        deleteButton.className =
            "action-btn delete-btn";

        deleteButton.textContent = "Delete";

        deleteButton.addEventListener("click", () => {
            deleteTransaction(transaction.id);
        });


        actionCell.appendChild(editButton);
        actionCell.appendChild(deleteButton);

        row.append(
            descriptionCell,
            categoryCell,
            dateCell,
            typeCell,
            amountCell,
            actionCell
        );

        tbody.appendChild(row);
    });


    table.style.display =
        visible.length ? "block" : "none";

    emptyState.style.display =
        visible.length ? "none" : "block";


    document.getElementById("transactionCount")
        .textContent =
            `${filtered.length} transaction` +
            `${filtered.length === 1 ? "" : "s"}` +
            (filtered.length > visible.length
                ? ` · Showing ${visible.length}`
                : "");


    const viewButton =
        document.getElementById("viewAllBtn");

    viewButton.textContent =
        showAllTransactions ? "Show Less" : "View All";

    viewButton.style.visibility =
        filtered.length > 7 ? "visible" : "hidden";
}


// ========================================
// ADD / EDIT MODAL
// ========================================

function openTransactionModal(id = null) {
    const modal =
        document.getElementById("transactionModal");

    const form =
        document.getElementById("transactionForm");

    form.reset();

    document.getElementById("transactionId").value = "";

    document.getElementById("date").value =
        todayString();

    document.getElementById("transactionType").value =
        "expense";

    document.querySelectorAll(".type-btn")
        .forEach(button => {
            button.classList.toggle(
                "active",
                button.dataset.type === "expense"
            );
        });

    renderCategories();

    document.getElementById("modalTitle").textContent =
        id ? "Edit Transaction" : "Add Transaction";


    if (id) {
        const transaction = transactions.find(
            item => item.id === id
        );

        if (!transaction) return;

        document.getElementById("transactionId").value =
            transaction.id;

        document.getElementById("description").value =
            transaction.description;

        document.getElementById("amount").value =
            transaction.amount;

        document.getElementById("date").value =
            transaction.date;

        document.getElementById("category").value =
            transaction.category;

        document.getElementById("notes").value =
            transaction.notes || "";

        document.getElementById("transactionType").value =
            transaction.type;

        document.querySelectorAll(".type-btn")
            .forEach(button => {
                button.classList.toggle(
                    "active",
                    button.dataset.type === transaction.type
                );
            });
    }

    modal.classList.add("show");

    document.body.style.overflow = "hidden";
}


function closeTransactionModal() {
    document
        .getElementById("transactionModal")
        .classList.remove("show");

    document.body.style.overflow = "";
}


// ========================================
// SAVE TRANSACTION
// ========================================

function saveTransaction(event) {
    event.preventDefault();

    const id = document
        .getElementById("transactionId")
        .value;

    const description = document
        .getElementById("description")
        .value.trim();

    const amount = Number(
        document.getElementById("amount").value
    );

    const date = document
        .getElementById("date")
        .value;

    const category = document
        .getElementById("category")
        .value;

    const type = document
        .getElementById("transactionType")
        .value;

    const notes = document
        .getElementById("notes")
        .value.trim();


    if (!description || !date || !category) {
        showToast("Please complete all required fields.");
        return;
    }

    if (!Number.isFinite(amount) || amount <= 0) {
        showToast("Enter an amount greater than zero.");
        return;
    }

    if (!["income", "expense"].includes(type)) {
        showToast("Choose a valid transaction type.");
        return;
    }

    if (date > todayString()) {
        const confirmFuture = confirm(
            "This transaction is dated in the future. Save it anyway?"
        );

        if (!confirmFuture) return;
    }


    const existing = transactions.find(
        item => item.id === id
    );

    const transaction = {
        id: id || (
            crypto.randomUUID
                ? crypto.randomUUID()
                : String(Date.now())
        ),

        description,
        amount,
        date,
        category,
        type,
        notes,

        createdAt: existing
            ? existing.createdAt
            : Date.now()
    };


    const oldTransactions = [...transactions];

    if (existing) {
        transactions = transactions.map(item =>
            item.id === id ? transaction : item
        );
    } else {
        transactions.push(transaction);
    }


    if (!saveData()) {
        transactions = oldTransactions;
        return;
    }

    closeTransactionModal();

    renderAll();

    showToast(
        existing
            ? "Transaction updated successfully!"
            : "Transaction added successfully!"
    );
}


// ========================================
// DELETE TRANSACTION
// ========================================

function deleteTransaction(id) {
    const transaction = transactions.find(
        item => item.id === id
    );

    if (!transaction) return;

    const confirmed = confirm(
        `Delete "${transaction.description}"?`
    );

    if (!confirmed) return;

    const oldTransactions = [...transactions];

    transactions = transactions.filter(
        item => item.id !== id
    );

    if (!saveData()) {
        transactions = oldTransactions;
        return;
    }

    renderAll();

    showToast("Transaction deleted successfully!");
}


// ========================================
// EXPENSE CHART
// ========================================

function renderChart() {
    const canvas =
        document.getElementById("expenseChart");

    const empty =
        document.getElementById("chartEmpty");

    if (typeof Chart === "undefined") {
        empty.textContent =
            "Charts require an internet connection to load.";

        empty.style.display = "flex";

        return;
    }

    const mode =
        document.getElementById("chartType").value;

    let labels = [];
    let values = [];


    if (mode === "category") {
        const grouped = {};

        transactions
            .filter(item => item.type === "expense")
            .forEach(item => {
                grouped[item.category] =
                    (grouped[item.category] || 0) +
                    Number(item.amount);
            });

        labels = Object.keys(grouped).sort(
            (a, b) => grouped[b] - grouped[a]
        );

        values = labels.map(label => grouped[label]);

    } else {
        const grouped = {};

        transactions
            .filter(item => item.type === "expense")
            .forEach(item => {
                const key = monthKey(item.date);

                grouped[key] =
                    (grouped[key] || 0) +
                    Number(item.amount);
            });

        const keys = Object.keys(grouped)
            .sort()
            .slice(-6);

        labels = keys.map(monthName);

        values = keys.map(key => grouped[key]);
    }


    if (expenseChart) {
        expenseChart.destroy();
        expenseChart = null;
    }

    empty.style.display =
        values.length ? "none" : "flex";

    if (!values.length) {
        return;
    }


    const colors = [
        "#16a085",
        "#f4a261",
        "#e76f85",
        "#8e83e8",
        "#5a9bd5",
        "#e9c46a",
        "#52b788",
        "#c77dce",
        "#ef8354",
        "#8d99ae"
    ];


    expenseChart = new Chart(
        canvas.getContext("2d"),
        {
            type: mode === "category"
                ? "doughnut"
                : "bar",

            data: {
                labels,

                datasets: [{
                    label: "Expenses",
                    data: values,

                    backgroundColor: colors,

                    borderWidth: 0,

                    borderRadius:
                        mode === "month" ? 7 : 0,

                    hoverOffset: 7
                }]
            },

            options: {
                responsive: true,

                maintainAspectRatio: false,

                cutout:
                    mode === "category"
                        ? "66%"
                        : undefined,

                plugins: {
                    legend: {
                        position:
                            mode === "category"
                                ? "right"
                                : "top",

                        labels: {
                            usePointStyle: true,
                            pointStyle: "circle",
                            boxWidth: 8,
                            padding: 14,

                            color: "#7f8c9b",

                            font: {
                                family: "DM Sans",
                                size: 10
                            }
                        }
                    },

                    tooltip: {
                        callbacks: {
                            label(context) {
                                return (
                                    context.label +
                                    ": " +
                                    money(context.raw)
                                );
                            }
                        }
                    }
                },

                scales: mode === "month"
                    ? {
                        x: {
                            grid: {
                                display: false
                            },

                            ticks: {
                                color: "#8995a5",
                                font: {
                                    size: 10
                                }
                            },

                            border: {
                                display: false
                            }
                        },

                        y: {
                            beginAtZero: true,

                            grid: {
                                color: "#edf1f5"
                            },

                            ticks: {
                                color: "#8995a5",

                                callback(value) {
                                    return "₹" + value;
                                }
                            },

                            border: {
                                display: false
                            }
                        }
                    }
                    : {}
            }
        }
    );
}


// ========================================
// REFRESH ALL APPLICATION DATA
// ========================================

function renderAll() {
    renderSummary();

    renderCategories();

    renderTransactions();

    renderChart();
}


// ========================================
// EVENT LISTENERS
// ========================================

document
    .getElementById("addTransactionBtn")
    .addEventListener("click", () => {
        openTransactionModal();
    });


document
    .getElementById("emptyAddBtn")
    .addEventListener("click", () => {
        openTransactionModal();
    });


document
    .getElementById("closeModal")
    .addEventListener("click", closeTransactionModal);


document
    .getElementById("cancelModal")
    .addEventListener("click", closeTransactionModal);


document
    .getElementById("transactionForm")
    .addEventListener("submit", saveTransaction);


document
    .getElementById("categoryForm")
    .addEventListener("submit", addCategory);


document
    .getElementById("transactionModal")
    .addEventListener("click", event => {
        if (event.target.id === "transactionModal") {
            closeTransactionModal();
        }
    });


document
    .getElementById("transactionModal")
    .addEventListener("keydown", event => {
        if (event.key === "Escape") {
            closeTransactionModal();
        }
    });


document
    .querySelectorAll(".type-btn")
    .forEach(button => {
        button.addEventListener("click", () => {
            const type = button.dataset.type;

            document.getElementById(
                "transactionType"
            ).value = type;

            document
                .querySelectorAll(".type-btn")
                .forEach(item => {
                    item.classList.toggle(
                        "active",
                        item === button
                    );
                });
        });
    });


// Search and filters.

[
    "searchInput",
    "filterType",
    "filterCategory",
    "startDate",
    "endDate"
].forEach(id => {
    const element = document.getElementById(id);

    element.addEventListener(
        id === "searchInput" ? "input" : "change",
        () => {
            showAllTransactions = false;
            renderTransactions();
        }
    );
});


// Clear all filters.

document
    .getElementById("clearFilters")
    .addEventListener("click", () => {
        document.getElementById("searchInput").value = "";

        document.getElementById("filterType").value =
            "all";

        document.getElementById("filterCategory").value =
            "all";

        document.getElementById("startDate").value = "";

        document.getElementById("endDate").value = "";

        showAllTransactions = false;

        renderTransactions();

        showToast("Filters cleared.");
    });


// Show all transactions / show fewer.

document
    .getElementById("viewAllBtn")
    .addEventListener("click", () => {
        showAllTransactions = !showAllTransactions;

        renderTransactions();
    });


// Switch chart view.

document
    .getElementById("chartType")
    .addEventListener("change", renderChart);


// Navigation active state.

document
    .querySelectorAll(".nav-link")
    .forEach(link => {
        link.addEventListener("click", () => {
            document
                .querySelectorAll(".nav-link")
                .forEach(item => {
                    item.classList.remove("active");
                });

            link.classList.add("active");
        });
    });


// ========================================
// INITIALIZE APPLICATION
// ========================================

renderAll();
